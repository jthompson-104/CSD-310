-- CHARLIE DB SCRIPT INSTRUCTIONS --

- Make sure all scripts are in the same folder
- The module Pretty Tables needs to be installed to run report script
- Run 'Charlie_db_main_v2' first to create the database
- Run 'Charlie_db_reports_v2' to run some reports